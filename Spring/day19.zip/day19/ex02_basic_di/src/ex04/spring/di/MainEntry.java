package ex04.spring.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainEntry {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("ex04/spring/di/appCtx.xml");
		//�������̽� Ÿ������ ���� ����
//		IRecordView view = (IRecordViewImpl)context.getBean("view");
		IRecordView view = context.getBean("view", IRecordViewImpl.class);
		view.input();
		view.print();
	}
}
