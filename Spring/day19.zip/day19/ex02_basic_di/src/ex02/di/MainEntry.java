package ex02.di;

public class MainEntry {
	public static void main(String[] args) {
		NewRecordView view = new NewRecordView();
		NewRecord record = new NewRecord(1,2,3,4);
		view.setRecord(record);
		view.print();
	}
}
